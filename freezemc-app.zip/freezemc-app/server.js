require("dotenv").config();

const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const path = require("path");

const { readDb, writeDb } = require("./data/db");
const { requireAuth } = require("./middleware/auth");
const { featureIcon, forumIcon } = require("./helpers/icons");

const app = express();
const upload = multer(); // multipart/form-data text alanlarını parse etmek için (dosya yok)

const PORT = process.env.PORT || 3000;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin";
const SESSION_SECRET = process.env.SESSION_SECRET || "freezemc-dev-secret-degistir";

// ---------- View engine ----------
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// expose helper fonksiyonlarını tüm EJS view'larına otomatik aktarmak için
app.use((req, res, next) => {
  res.locals.featureIcon = featureIcon;
  res.locals.forumIcon = forumIcon;
  next();
});

// ---------- Middleware ----------
app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 8 } // 8 saat
  })
);

// ============================================================
//  PUBLIC SITE ROUTES
// ============================================================

app.get("/", (req, res) => {
  const db = readDb();
  res.render("index", { site: db.site });
});

app.get("/kurallar", (req, res) => {
  const db = readDb();
  res.render("kurallar", { site: db.site, rules: db.rules });
});

app.get("/magaza", (req, res) => {
  const db = readDb();
  res.render("magaza", { site: db.site, store: db.store });
});

app.get("/forum", (req, res) => {
  const db = readDb();
  res.render("forum", { site: db.site, forum: db.forum });
});

// ============================================================
//  ADMIN AUTH ROUTES
// ============================================================

app.get("/admin", (req, res) => {
  res.redirect(req.session && req.session.isAdmin ? "/admin/dashboard" : "/admin/login");
});

app.get("/admin/login", (req, res) => {
  if (req.session && req.session.isAdmin) return res.redirect("/admin/dashboard");
  res.render("admin/login", { error: null });
});

app.post("/admin/login", upload.none(), (req, res) => {
  const { username, password } = req.body;

  const validUsername = username === ADMIN_USERNAME;
  const validPassword = password === ADMIN_PASSWORD;

  if (validUsername && validPassword) {
    req.session.isAdmin = true;
    return res.redirect("/admin/dashboard");
  }

  res.render("admin/login", { error: "Kullanıcı adı veya şifre hatalı." });
});

app.post("/admin/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/admin/login");
  });
});

// ============================================================
//  ADMIN DASHBOARD
// ============================================================

app.get("/admin/dashboard", requireAuth, (req, res) => {
  const db = readDb();
  res.render("admin/dashboard", { db });
});

// ============================================================
//  ADMIN API — kaydetme uç noktaları
//  Hepsi multipart/form-data ile POST edilir, JSON cevap döner.
// ============================================================

// ---- SITE ----
app.post("/admin/api/site", requireAuth, upload.none(), (req, res) => {
  try {
    const db = readDb();
    const b = req.body;

    db.site.serverIp = b.serverIp || "";
    db.site.serverVersion = b.serverVersion || "";
    db.site.serverType = b.serverType || "";
    db.site.heroTag = b.heroTag || "";
    db.site.heroSubtitle = b.heroSubtitle || "";
    db.site.discordUrl = b.discordUrl || "#";
    db.site.youtubeUrl = b.youtubeUrl || "#";
    db.site.twitterUrl = b.twitterUrl || "#";

    db.site.stats = arrify(b.stats).map((s) => ({
      num: s.num || "",
      label: s.label || ""
    }));

    db.site.regions = arrify(b.regions).map((r) => ({
      tag: r.tag || "",
      name: r.name || "",
      desc: r.desc || "",
      pvp: r.pvp || "",
      claim: r.claim || ""
    }));

    db.site.features = arrify(b.features).map((f) => ({
      icon: f.icon || "star",
      title: f.title || "",
      desc: f.desc || ""
    }));

    writeDb(db);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Kaydetme hatası: " + err.message });
  }
});

// ---- STORE ----
app.post("/admin/api/store", requireAuth, upload.none(), (req, res) => {
  try {
    const db = readDb();
    const b = req.body;

    db.store.note = b.note || "";

    db.store.products = arrify(b.products).map((p) => ({
      id: slugify(p.name || "urun"),
      tier: p.tier || "",
      name: p.name || "",
      price: p.price || "",
      priceNote: p.priceNote || "",
      featured: p.featured === "on" || p.featured === true,
      ribbon: p.ribbon || "",
      perks: (p.perksRaw || "")
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean)
    }));

    writeDb(db);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Kaydetme hatası: " + err.message });
  }
});

// ---- RULES ----
app.post("/admin/api/rules", requireAuth, upload.none(), (req, res) => {
  try {
    const db = readDb();
    const b = req.body;

    db.rules.sections = arrify(b.sections).map((sec) => ({
      id: sec.id || slugify(sec.title || "bolum"),
      num: sec.num || "",
      title: sec.title || "",
      items: arrify(sec.items).map((item) => ({
        code: item.code || "",
        title: item.title || "",
        desc: item.desc || "",
        penalty: item.penalty || "",
        penaltyLevel: item.penaltyLevel || ""
      }))
    }));

    writeDb(db);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Kaydetme hatası: " + err.message });
  }
});

// ---- FORUM ----
app.post("/admin/api/forum", requireAuth, upload.none(), (req, res) => {
  try {
    const db = readDb();
    const b = req.body;

    db.forum.categories = arrify(b.categories).map((c) => ({
      icon: c.icon || "chat",
      name: c.name || "",
      desc: c.desc || "",
      count: c.count || "0"
    }));

    db.forum.threads = arrify(b.threads).map((t) => ({
      id: Number(t.id) || Date.now(),
      tag: t.tag || "genel",
      tagLabel: t.tagLabel || "Genel",
      title: t.title || "",
      author: t.author || "",
      time: t.time || "",
      replies: Number(t.replies) || 0
    }));

    writeDb(db);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Kaydetme hatası: " + err.message });
  }
});

// ============================================================
//  HELPERS
// ============================================================

// Express'in urlencoded/multer parser'ı "stats[0][num]" gibi alanları
// { '0': { num: '...' } } şeklinde bir objeye çevirir. Bu objeyi
// index sırasına göre düz bir diziye çeviriyoruz.
function arrify(obj) {
  if (!obj) return [];
  if (Array.isArray(obj)) return obj;
  return Object.keys(obj)
    .sort((a, b) => Number(a) - Number(b))
    .map((k) => obj[k]);
}

function slugify(str) {
  return String(str)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9ığüşöç\s-]/gi, "")
    .replace(/\s+/g, "-")
    .replace(/^-+|-+$/g, "") || "item-" + Date.now();
}

// ============================================================
//  404
// ============================================================

app.use((req, res) => {
  res.status(404).send("Sayfa bulunamadı.");
});

app.listen(PORT, () => {
  console.log(`FreezeMC sitesi http://localhost:${PORT} adresinde çalışıyor`);
  console.log(`Admin panel: http://localhost:${PORT}/admin`);
});
