# FreezeMC — Site + Admin Panel

Bu proje artık statik bir HTML sitesi değil, **Node.js (Express) ile çalışan dinamik bir uygulama**. Tüm site içeriği (`data/db.json`) bir admin panelinden değiştirilebiliyor ve değişiklikler anında siteye yansıyor.

## Yerelde çalıştırma

1. [Node.js](https://nodejs.org) kurulu olmalı (18 veya üzeri önerilir).
2. Bu klasörde terminal aç:
   ```
   npm install
   ```
3. `.env.example` dosyasını kopyala ve `.env` olarak adlandır, içindeki kullanıcı adı/şifreyi **mutlaka değiştir**:
   ```
   ADMIN_USERNAME=admin
   ADMIN_PASSWORD=guclu-bir-sifre-yaz
   SESSION_SECRET=uzun-rastgele-bir-metin
   PORT=3000
   ```
4. Sunucuyu başlat:
   ```
   npm start
   ```
5. Site: `http://localhost:3000`
   Admin panel: `http://localhost:3000/admin`

## Admin panelden neler değiştirilebiliyor?

- **Site İçeriği**: Sunucu IP'si, sürüm/tür etiketleri, hero metni, sosyal linkler, istatistik şeridi, bölgeler (faction grid), özellik kartları.
- **Mağaza**: Rütbe/ürün ekleme-silme, fiyat, özellik listesi, "öne çıkan" etiketi.
- **Kurallar**: Bölüm ve madde ekleme-silme, ceza etiketleri (yok / düşük / ağır).
- **Forum**: Kategori ve konu ekleme-silme.

Tüm değişiklikler `data/db.json` dosyasına kaydedilir ve sayfa yenilenince herkese görünür.

## Hosting'e yükleme

Bu artık bir Node.js uygulaması olduğu için **statik dosya hosting'i (sadece HTML/CSS barındıran hizmetler) çalışmaz.** Node.js çalıştırabilen bir hosting gerekiyor. Örnekler: Render, Railway, Fly.io, bir VPS (kendi sunucu), veya Node destekleyen paylaşımlı hosting.

Genel adımlar:
1. Bu klasörü (node_modules ve .env hariç) hosting'e yükle / GitHub'a pushla.
2. Hosting panelinde ortam değişkenlerini (`ADMIN_USERNAME`, `ADMIN_PASSWORD`, `SESSION_SECRET`, `PORT`) gir — `.env` dosyasını sunucuya yüklemek yerine genelde hosting panelinden bu değerleri tanımlarsın.
3. Başlatma komutu: `npm install && npm start`.
4. Hosting sana bir adres verecek (örn. `freezemc.onrender.com`); istersen sonradan kendi alan adını (`freezemc.net` gibi) buna yönlendirebilirsin.

**Önemli güvenlik notu:** `.env` dosyasındaki `ADMIN_PASSWORD` ve `SESSION_SECRET` değerlerini gerçek, tahmin edilemez değerlerle değiştirmeden canlıya almayın. `.env` dosyasını asla GitHub'a yüklemeyin (`.gitignore` içinde zaten hariç tutuldu).

## Klasör yapısı

```
freezemc-app/
├── server.js              # Ana Express sunucusu, tüm rotalar
├── data/
│   ├── db.json             # Tüm site verisi (admin panel buraya yazar)
│   └── db.js                # JSON okuma/yazma yardımcıları
├── middleware/
│   └── auth.js              # Admin oturum kontrolü
├── helpers/
│   └── icons.js              # Özellik/forum ikonları (SVG)
├── views/                    # EJS template'leri (sayfalar)
│   ├── index.ejs, kurallar.ejs, magaza.ejs, forum.ejs
│   ├── partials/header.ejs, footer.ejs
│   └── admin/login.ejs, dashboard.ejs
└── public/
    ├── css/main.css, pages.css, admin.css
    └── js/main.js, admin.js
```
