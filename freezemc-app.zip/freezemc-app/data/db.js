// Basit JSON dosya tabanlı "veritabanı" katmanı.
// Küçük/orta trafikli bir sunucu sitesi için yeterlidir.
// Her yazma işleminde dosyaya senkron olarak kaydedilir.

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "db.json");

function readDb() {
  const raw = fs.readFileSync(DB_PATH, "utf-8");
  return JSON.parse(raw);
}

function writeDb(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf-8");
}

module.exports = { readDb, writeDb };
